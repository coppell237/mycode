#!/usr/bin/env python3

"""
Author: RZFeeser

This program prints some things to the screen
"""

def main():
    """Our main program"""
    mynote = 'print this string' # define mynote
    print(mynote)                # display our string

main()


######## original ######
##!/usr/bin/env python3
#mynote = "print this string"
#print(mynote)


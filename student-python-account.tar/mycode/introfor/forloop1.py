#!/usr/bin/env python3
vendors = ["cisco", "juniper", "big_ip", "f5", "arista"]

#loop across the list vendors

for x in vendors:
    print("The vendor is:" +x)     # looping until end of list

print("\nOur loop has ended")

#!/usr/bin/env python3
animals=["Fox", "Fly", "Ant"]
print(animals)
